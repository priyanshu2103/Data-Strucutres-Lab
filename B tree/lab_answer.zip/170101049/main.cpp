#include <bits/stdc++.h>
using namespace std;

int max_keys;
int min_degree;

typedef struct _node
{
	struct _node* parent;
	int num_keys;
	int num_children;
	bool isLeaf;
	int node_id;
	int depth;
}node;

node* createNode(int id,int keys,int children,int pops,node* arr[],int count)
{
	node* p=(node*)malloc(sizeof(struct _node));
	p->node_id=id;
	p->num_keys=keys;
	p->num_children=children;

	if(count==0)
	{
		p->parent=NULL;
		p->depth=0;
		p->isLeaf=true;
	}
	else
	{
		int flag=0;
		for(int i=0;i<count;i++)
		{
			if(arr[i]->node_id==pops)
			{
				p->parent=arr[i];
				p->depth=p->parent->depth+1;
				p->parent->isLeaf=false;
				p->isLeaf=true;
				flag=1;
			}
		}
		if(flag!=1)
		{
			cout<<"You inserted a node whose parent you have not yet described"<<endl;
			return NULL;
		}
	}
	return p;
}

int main()
{	
	cin>>max_keys;
	int num_nodes;
	cin>>num_nodes;
	int count=0; // this will keep track that how many elements has been inserted till now

	min_degree=(max_keys+1)/2;

	node* arr[num_nodes];
	for(int i=0;i<num_nodes;i++)
	{
		int x,p,y,z;
		cin>>x>>p>>y>>z;
		
		if(y<min_degree-1&&p!=0)
		{
			cout<<"Answer: This cannot be a valid BTree"<<endl;
			cout<<"Reason: Node with node id "<<x<<" does not satisfy minimum occupancy"<<endl;
			return 0;
		}
		arr[i]=createNode(x,y,z,p,arr,count);
		if(arr[i]==NULL)
			return 0;

		count++;
	}

	vector<int> leaf_dep;
	vector<int> leaf_id;

	for(int i=0;i<num_nodes;i++)
	{
		if(arr[i]->isLeaf==true){
			leaf_dep.push_back(arr[i]->depth);
			leaf_id.push_back(arr[i]->node_id);
		}
	}

	for(int i=1;i<leaf_dep.size();i++)
	{
		if(leaf_dep[i]!=leaf_dep[i-1])
		{
			cout<<"Answer: This cannot be a valid BTree"<<endl;
			cout<<"Reason: Nodes with node id "<<leaf_id[i]<<" and "<<leaf_id[i-1]<<" are a pair of leaf nodes that do not have the same depth"<<endl;
			return 0;
		}
	}

	for(int i=0;i<num_nodes;i++)
	{
		if(arr[i]->isLeaf==false)
		{
			if(arr[i]->num_children!=arr[i]->num_keys+1)
			{
				cout<<"Answer: This cannot be a valid BTree"<<endl;
				cout<<"Reason: Node with node id "<<arr[i]->node_id<<" does not satisfy the requirement that Children count = Key count + 1"<<endl;
				return 0;
			}
		}
	}

	cout<<"Answer: This can be a valid B Tree"<<endl;
	return 0;

}